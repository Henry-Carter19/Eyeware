import React from "react";

const RegisterForm = () => {
  return null;
};

export default RegisterForm;
