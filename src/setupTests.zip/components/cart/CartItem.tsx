import React from "react";

const CartItem = () => {
  return null;
};

export default CartItem;
