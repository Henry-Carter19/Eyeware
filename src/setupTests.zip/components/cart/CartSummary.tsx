import React from "react";

const CartSummary = () => {
  return null;
};

export default CartSummary;
