import React from "react";

const CartDrawer = () => {
  return null;
};

export default CartDrawer;
