import React from "react";

const Footer = () => {
  return null;
};

export default Footer;
