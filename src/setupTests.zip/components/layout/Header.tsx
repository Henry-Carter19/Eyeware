import React from "react";

const Header = () => {
  return null;
};

export default Header;
