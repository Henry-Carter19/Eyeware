import React from "react";

const MegaMenu = () => {
  return null;
};

export default MegaMenu;
