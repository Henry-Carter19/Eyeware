import React from "react";

const FilterSidebar = () => {
  return null;
};

export default FilterSidebar;
