import React from "react";

const ProductGallery = () => {
  return null;
};

export default ProductGallery;
