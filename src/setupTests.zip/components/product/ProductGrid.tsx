import React from "react";

const ProductGrid = () => {
  return null;
};

export default ProductGrid;
