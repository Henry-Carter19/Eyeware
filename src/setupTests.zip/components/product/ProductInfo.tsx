import React from "react";

const ProductInfo = () => {
  return null;
};

export default ProductInfo;
