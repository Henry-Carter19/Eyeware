import React from "react";

const SortDropdown = () => {
  return null;
};

export default SortDropdown;
