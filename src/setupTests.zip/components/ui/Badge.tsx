import React from "react";

const Badge = () => {
  return null;
};

export default Badge;
