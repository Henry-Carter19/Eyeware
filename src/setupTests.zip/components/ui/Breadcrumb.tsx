import React from "react";

const Breadcrumb = () => {
  return null;
};

export default Breadcrumb;
