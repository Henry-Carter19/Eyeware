import React from "react";

const Button = () => {
  return null;
};

export default Button;
