import React from "react";

const Drawer = () => {
  return null;
};

export default Drawer;
