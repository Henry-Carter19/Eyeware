import React from "react";

const Input = () => {
  return null;
};

export default Input;
