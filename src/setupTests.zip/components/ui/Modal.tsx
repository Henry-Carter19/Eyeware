import React from "react";

const Modal = () => {
  return null;
};

export default Modal;
