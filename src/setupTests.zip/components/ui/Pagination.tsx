import React from "react";

const Pagination = () => {
  return null;
};

export default Pagination;
