import React from "react";

const Rating = () => {
  return null;
};

export default Rating;
