import React from "react";

const Tabs = () => {
  return null;
};

export default Tabs;
