import React from "react";

const Toggle = () => {
  return null;
};

export default Toggle;
