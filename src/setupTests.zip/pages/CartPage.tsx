import React from "react";

const CartPage = () => {
  return null;
};

export default CartPage;
