import React from "react";

const CheckoutPage = () => {
  return null;
};

export default CheckoutPage;
