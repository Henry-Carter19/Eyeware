import React from "react";

const NotFoundPage = () => {
  return <h2>404 - Page Not Found</h2>;
};

export default NotFoundPage;