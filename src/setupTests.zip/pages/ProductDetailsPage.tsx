import React from "react";

const ProductDetailsPage = () => {
  return null;
};

export default ProductDetailsPage;
