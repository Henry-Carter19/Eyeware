import React from "react";

const SignInPage = () => {
  return null;
};

export default SignInPage;
