import React from "react";

const StoreLocatorPage = () => {
  return null;
};

export default StoreLocatorPage;
