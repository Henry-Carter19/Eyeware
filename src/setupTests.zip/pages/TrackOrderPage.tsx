import React from "react";

const TrackOrderPage = () => {
  return null;
};

export default TrackOrderPage;
