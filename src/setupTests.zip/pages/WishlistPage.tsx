import React from "react";

const WishlistPage = () => {
  return null;
};

export default WishlistPage;
